﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExAvocateprog15.Classes
{
    public class ExAvApplication
    {
        public int ExAvId { get; private set; }
        public string Description { get; private set; }
        public string Month { get; private set; }
        public ExAvApplication(int ExAvId, string Description, string Month)
        {
            this.ExAvId = ExAvId;
            this.Description = Description;
            this.Month = Month;
        }

    }
}